<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
JPlugin::loadLanguage( 'tpl_SG1' );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
<head>
<jdoc:include type="head" />

<link rel="stylesheet" href="templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="templates/<?php echo $this->template; ?>/css/ja-sosdmenu.css" type="text/css" />
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/template.css" type="text/css" />

<!--[if lte IE 6]>
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/ie7.css" type="text/css" />
<![endif]-->

</head>
<body class="body_bg">

	<div id="page_bg">
		<div id="page_bg1">
		<!--header start -->
		<div id="header" style="position: relative; ">
			<div id="logo" style="bottom:0px; position:absolute; ">
				<table cellspacing="0" cellpadding="0" style="width: 900px; height: 60px; text-align: center; margin: 0 auto;">
					<tr><td style="text-align: center; vertical-align: middle;">
						<a href="index.php">Moksha @ www.TripNaksha.com</a>
						<!--a href="index.php"><?php echo $mainframe->getCfg('sitename') ;?></a-->
						<!--a href="index.php" title="<?php echo $siteName; ?>"><span><?php echo $siteName; ?></span></a-->
					</td></tr>
				</table>
			</div>	
		</div>
		<!--header end -->
		
		<!--topmenu start-->
		<div class="pill_m">
			<div id="ja-mainnavwrap">
				<div id="ja-mainnav" class="clearfix">
				<jdoc:include type="modules" name="hornav" />
				</div>
			</div>
			<div id="pillmenu">
			<table cellspacing="0" cellpadding="0" style="margin: 0 auto;">
				<tr><td>
				<jdoc:include type="modules" name="user3" />
				</td></tr>
			</table>
			</div>
		</div>	
		
		<!--topmenu end-->
		
		<!--center start-->
		<div class="center">
			<div id="wrapper">
				<div id="content">
					<!--pathway start-->
					<div class="cpathway">
						<jdoc:include type="module" name="breadcrumbs" />
					</div>
					<!--pathway end-->
					<?php if($this->countModules('left') and JRequest::getCmd('layout') != 'form') : ?>
						<div id="leftcolumn" style="margin:25px 0 0 0;">	
							<jdoc:include type="modules" name="left" style="rounded" />
							<?php //$wd123 = 'banner'; include "templates.php"; ?>
						</div>
						<?php endif; ?>
						
						<?php if($this->countModules('right') and JRequest::getCmd('layout') != 'form') : ?>
						<div id="maincolumn">
						<?php else: ?>
						<div id="maincolumn_full">
						<?php endif; ?>
							<div class="nopad">			
								<jdoc:include type="message" />
								<jdoc:include type="modules" name="user4" />&nbsp;
								<div>&nbsp;</div>
								<div style="float: right;">
									<jdoc:include type="modules" name="taf" style="xhtml" />
								</div>
								<div>&nbsp;</div>
								<div>&nbsp;</div>
								<?php if($this->params->get('showComponent')) : ?>
									<jdoc:include type="component" />
								<?php endif; ?>
							</div>
						</div>
						
						<?php if($this->countModules('right') and JRequest::getCmd('layout') != 'form') : ?>
						<div id="rightcolumn" style="float:right;">
							<jdoc:include type="modules" name="right" style="rounded" />								
						</div>
					<?php endif; ?>
					<div class="clr"></div>
				</div>		
			</div>
		</div>
		<!--center end-->
		
		
	</div>	
	</div>
		<!--footer start-->
		<div id="footer">
			<div id="links">
				<div style="text-align: center; padding: 24px 0 0;">
					<div >
					|&nbsp;<a class="footer123" href="index.php?option=com_content&view=article&id=164&Itemid=21" target="_blank">Privacy</a> &nbsp;|&nbsp;
					<a class="footer123" href="index.php?option=com_content&view=article&id=165&Itemid=21" target="_blank">Terms</a>&nbsp;|&nbsp;
					<a class="footer123" href="index.php?option=com_content&view=article&id=166&Itemid=21" target="_blank">Contact</a>&nbsp;|
					<a class="footer123" href="http://tripnaksha.blogspot.com/" target="_blank">Blog</a>&nbsp;|&nbsp;
					</div>
				</div> 
				<div style="text-align: center; padding: 0 0 0;">
					<jdoc:include type="modules" name="footer" style="xhtml" />
					<?php $wd123 = ''; include "templates.php"; ?>
				</div> 
			</div>
			
			<!--div id="f123">
				<div>
					<div style="text-align: center; padding: 24px 0 0;">
						<?php $wd123 = ''; include "templates.php"; ?>
					</div> 
					<div style=" padding: 5px 0; text-align: center; color: #fff;">
						Valid <a style="color: #fff;" href="http://validator.w3.org/check/referer">XHTML</a> and <a style="color: #fff;" href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a>.
					</div>
				</div>
			</div-->
		</div>
		<!--footer end-->	
	<jdoc:include type="modules" name="debug" />
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-4899076-4");
pageTracker._trackPageview();
} catch(err) {}</script>	
		
</body>
</html>
