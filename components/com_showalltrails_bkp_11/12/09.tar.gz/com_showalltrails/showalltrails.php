 <?php
// no direct access
defined('_JEXEC') or die('Restricted access');

	// Get instance of database object
	$db =& JFactory::getDBO();

	//require_once(JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'search.php' );
	require_once(JPATH_SITE.DS.'administrator'.DS.'components'.DS.'com_search'.DS.'helpers'.DS.'search.php');
	require_once (JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');

	$limit = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
        $limitstart = JRequest::getVar('limitstart', 0, '', 'int');
        $params = new JParameter( $paramsdata, $paramsdefs );

        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);

	$query = " SELECT 1 \n" .
		 " FROM #__trailList AS b LEFT JOIN #__users c \n" .
		 " ON b.userId = c.id \n" .
		 " WHERE b.private = 0 \n";
	$db->setQuery($query);
	$rows = $db->loadObjectList();
	$total = count($rows);

	// Create the pagination object
	jimport('joomla.html.pagination');
	$pagination = new JPagination($total, $limitstart, $limit);

	$query = " SELECT b.id, b.name as tname, b.nname, b.nemail, b.routeStart, b.mapCenter, \n" .
		 "  b.userId, b.length, DATE_FORMAT(b.createtime,'%d %b %y') as ttime, c.name as uname\n" .
		 " FROM #__trailList AS b LEFT JOIN #__users c \n" .
		 " ON b.userId = c.id \n" .
		 " WHERE b.private = 0 \n" .
		 " ORDER BY b.createtime desc \n";
	$db->setQuery($query, $pagination->limitstart, $pagination->limit);
	$rows = $db->loadObjectList();
?>
<div >
<div class="componentheading">
<?php echo 'All Trails'; ?>
</div>
<table cellspacing="0" cellpadding="0" border="0" width="100%" class="contenttable<?php echo $params->get( 'pageclass_sfx' ); ?>">
	<form action="<?php echo $this->action; ?>" method="post" name="adminForm">
	<div style="float:right">
	<?php
		echo JText::_('Display Num');
		echo $pagination->getLimitBox();
	?>
	</div>
	<div style="clear:right">&nbsp</div>
<thead>
	<tr>
		<th align="center" width="7%" class="sectiontableheader<?php echo $params->get( 'pageclass_sfx' ); ?>">#</th>
	 	<th align="left" width="43%" class="sectiontableheader<?php echo $params->get( 'pageclass_sfx' ); ?>">
	 		<a title="Click to sort by this column" href="javascript:tableOrdering('a.title','desc','');">Trail Name</a></th>
		<th nowrap="nowrap" align="left" width="15%" class="sectiontableheader<?php echo $params->get( 'pageclass_sfx' ); ?>">
			<a title="Click to sort by this column" href="javascript:tableOrdering('a.hits','desc','');">Created on</a></th>
		<th align="left" width="20%" class="sectiontableheader<?php echo $params->get( 'pageclass_sfx' ); ?>">
			<a title="Click to sort by this column" href="javascript:tableOrdering('author','desc','');">Mapped by</a></th>
		<th nowrap="nowrap" align="center" width="10%" class="sectiontableheader<?php echo $params->get( 'pageclass_sfx' ); ?>">
			<a title="Click to sort by this column" href="javascript:tableOrdering('a.hits','desc','');">Length of Trail</a></th>
	</tr>
</thead>
<tbody>
<?php
		$i = $limitstart;
		foreach ( $rows as $row )
		{
		  $i++;
?>
	<tr class="sectiontableentry1">
		<td align="center" >
		<?php echo $i;?>
		</td>
		<td>
		<a href="<?php echo JURI::base() . 'index.php?option=com_traildisplay&Itemid=1&tview=' . $row->id . '&trailname=' . str_replace(' ', '-', $row->tname);?>"><?php echo $row->tname;?></a>
		</td>
		<td>
		<?php echo $row->ttime;?>
		</td>
		<td>
			<?php if ($row->uname): ?>
			<a href="index.php?option=com_comprofiler&task=userProfile&user=<?php echo $row->userId;?>"><?php echo $row->uname; ?></a>
			<?php elseif ($row->nname): echo $row->nname;?>
			<?php else: ?>
			Guest
			<?php endif; ?>
		</td>
		<td>
		<?php echo $row->length . " km";?>
		</td>
	</tr>
<?php
		}
?>
<tr>
	<td colspan="5">&nbsp;</td>
</tr>
<tr>
	<td align="center" colspan="4" class="sectiontablefooter<?php //echo $this->params->get( 'pageclass_sfx' ); ?>">
		<?php echo $pagination->getPagesLinks(); ?>
	</td>
</tr>
<tr>
	<td colspan="5" align="right">
		<?php echo $pagination->getPagesCounter(); ?>
	</td>
</tr>
</tbody>
</form>
</table>
