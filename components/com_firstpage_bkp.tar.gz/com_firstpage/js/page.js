jQuery(document).ready(function(){
var margin =jQuery("#image1").width()/2;
var width=jQuery("#image1").width();
var height=jQuery("#image1").height();

var maincolumn_full = document.getElementById('maincolumn_full');
var leftcolumn = document.getElementById('leftcolumn');
leftcolumn.parentNode.removeChild(leftcolumn);
maincolumn_full.style.width = "920px";

jQuery("#image2").stop().css({width:'0px',height:''+height+'px',marginLeft:''+margin+'px',opacity:'0.5'});
jQuery("#image4").stop().css({width:'0px',height:''+height+'px',marginLeft:''+margin+'px',opacity:'0.5'});
jQuery("#image6").stop().css({width:'0px',height:''+height+'px',marginLeft:''+margin+'px',opacity:'0.5'});
//jQuery("#reflection2").stop().css({width:'0px',height:''+height+'px',marginLeft:''+margin+'px'});

	jQuery("#image1").mouseover(function(){
		var $parent = jQuery(this).parent();
		var $newLi = jQuery('<div id=\"firstchild\">Mark your hikes, treks, long rides or any kind of trips on a map!</div>');
		if ($parent.find("div#firstchild").length != 0 ) {$parent.find("div#firstchild").remove();}
		window.setTimeout(function() {
		$parent.append($newLi);
		},1002);
		jQuery(this).stop().animate({width:'0px',height:''+height+'px',marginLeft:''+margin+'px',opacity:'0.5'},{duration:500});
		window.setTimeout(function() {
		jQuery("#image2").stop().animate({width:''+width+'px',height:''+height+'px',marginLeft:'0px',opacity:'1'},{duration:500});
		},500);
	});

	jQuery("#image2").click(function() {
		var $parent = jQuery(this).parent().parent();
		$parent.find("div#firstchild").remove();
		jQuery(this).stop().animate({width:'0px',height:''+height+'px',marginLeft:''+margin+'px',opacity:'0.5'},{duration:500});
		window.setTimeout(function() {
		jQuery("#image1").stop().animate({width:''+width+'px',height:''+height+'px',marginLeft:'0px',opacity:'1'},{duration:500});
		},500);
	});

	jQuery("div#firstchild").click(function(){
		var $parent = jQuery(this).parent().parent();
		$parent.find("div#firstchild").remove();
		jQuery(this).stop().animate({width:'0px',height:''+height+'px',marginLeft:''+margin+'px',opacity:'0.5'},{duration:500});
		window.setTimeout(function() {
		jQuery("#image1").stop().animate({width:''+width+'px',height:''+height+'px',marginLeft:'0px',opacity:'1'},{duration:500});
		},500);
	});

	jQuery("#image3").mouseover(function(){
		var $parent = jQuery(this).parent();
		var $newLi = jQuery('<div id=\"firstchild\">Share experiences from your trips or with gear you used. Check tips from other users.</div>');
		if ($parent.find("div#firstchild").length != 0 ) {$parent.find("div#firstchild").remove();}
		window.setTimeout(function() {
		$parent.append($newLi);
		},1002);
		jQuery(this).stop().animate({width:'0px',height:''+height+'px',marginLeft:''+margin+'px',opacity:'0.5'},{duration:500});
		window.setTimeout(function() {
		jQuery("#image4").stop().animate({width:''+width+'px',height:''+height+'px',marginLeft:'0px',opacity:'1'},{duration:500});
		},500);
	});

	jQuery("#image4").click(function(){
		var $parent = jQuery(this).parent().parent();
		$parent.find("div#firstchild").remove();
		jQuery(this).stop().animate({width:'0px',height:''+height+'px',marginLeft:''+margin+'px',opacity:'0.5'},{duration:500});
		window.setTimeout(function() {
		jQuery("#image3").stop().animate({width:''+width+'px',height:''+height+'px',marginLeft:'0px',opacity:'1'},{duration:500});
		},500);
	});

	jQuery("#image5").mouseover(function(){
		var $parent = jQuery(this).parent();
		var $newLi = jQuery('<div id=\"firstchild\">Plan your trips and show exactly where you want to go on the map, and let your co-travelers know too!</div>');
		if ($parent.find("div#firstchild").length != 0 ) {$parent.find("div#firstchild").remove();}
		window.setTimeout(function() {
		$parent.append($newLi);
		},1002);
		jQuery(this).stop().animate({width:'0px',height:''+height+'px',marginLeft:''+margin+'px',opacity:'0.5'},{duration:500});
		window.setTimeout(function() {
		jQuery("#image6").stop().animate({width:''+width+'px',height:''+height+'px',marginLeft:'0px',opacity:'1'},{duration:500});
		},500);
	});

	jQuery("#image6").click(function(){
		var $parent = jQuery(this).parent().parent();
		$parent.find("div#firstchild").remove();
		jQuery(this).stop().animate({width:'0px',height:''+height+'px',marginLeft:''+margin+'px',opacity:'0.5'},{duration:500});
		window.setTimeout(function() {
		jQuery("#image5").stop().animate({width:''+width+'px',height:''+height+'px',marginLeft:'0px',opacity:'1'},{duration:500});
		},500);
	});

});
