 <?php
// no direct access
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.mootools');

$path = JPATH_COMPONENT_SITE;
$comp = substr($path, strpos($path, 'components'));
$document =& JFactory::getDocument();
$document->addScript($comp . '/js/jquery-1.3.2.min.js');
$document->addScriptDeclaration ( 'jQuery.noConflict();' );
//$document->addStyleSheet($comp . '/css/jquery.css');
//$document->addScript($comp . '/js/jquery.js');
$document->addStyleSheet($comp . '/css/page.css');
$document->addScript($comp . '/js/page.js');

?>
<div id="container">
	<div id="first">
		<h2>1. Map your trails!</h2>
		<br />
		<!--div id="firstchild"><a href="http://google.com">Abc</a></div-->
		<div id="child">
			<img id="image1" src="<?php echo $comp; ?>/images/map.jpg" />
			<img id="image2" src="<?php echo $comp; ?>/images/roundedbg.jpg" />
		</div>
	</div>
	<div id="filler2">
		&nbsp;
	</div>
	<div id="second">
		<h2>2. Write about them! </h2>
		<br />
		<div id="child">
			<img id="image3" src="<?php echo $comp; ?>/images/write.jpg" />
			<img id="image4" src="<?php echo $comp; ?>/images/roundedbg.jpg" />
		</div>
	</div>
	<div id="filler2">
		&nbsp;
	</div>
	<div id="third">
		<h2>3. Plan your next trip!</h2>
		<br />
		<div id="child">
			<img id="image5" src="<?php echo $comp; ?>/images/write.jpg" />
			<img id="image6" src="<?php echo $comp; ?>/images/roundedbg.jpg" />
		</div>
	</div>
</div>
